package controller;

import business.Customers;
import business.MenuItems;
import business.Orders;
import view.Menu;
import util.Inputter;

public class Main {
    public static void main(String[] args) {
        // Khởi tạo danh sách khách hàng, thực đơn và đơn hàng từ file
        Customers customerList = new Customers();
        customerList.readFromFile(); // Đọc danh sách khách hàng từ file
        
        MenuItems menuList = new MenuItems();
        menuList.readFromFile(); // Đọc danh sách thực đơn từ file

        Orders orderList = new Orders();
        orderList.readFromFile(); // Đọc danh sách đơn hàng từ file

        int choice;
        do {
            Menu.displayMenu(); // Hiển thị menu
            choice = Menu.getUserChoice(); // Nhận lựa chọn từ người dùng

            switch (choice) {
                case 1:
                    customerList.addCustomer();
                    break;
                case 2:
                    customerList.updateCustomer();
                    break;
                case 3:
                    customerList.searchCustomerByName();
                    break;
                case 4:
                    menuList.displayAllMenus();
                    break;
                case 5:
                    orderList.placeOrder(customerList, menuList);
                    break;
                case 6:
                    orderList.updateOrder(menuList);
                    break;
                case 7:
                    orderList.saveToFile();
                    customerList.saveToFile();
                    System.out.println("Data has been saved successfully!");
                    break;
                case 8:
                    orderList.displayOrders();
                    customerList.displayCustomers();
                    break;
                case 9:
                    if (!orderList.isSaved() || !customerList.isSaved()) {
                        System.out.print("Do you want to save the data before exiting? (Y/N): ");
                        String confirm = Inputter.getString("").toUpperCase();
                        if (confirm.equals("Y")) {
                            orderList.saveToFile();
                            customerList.saveToFile();
                            System.out.println("Data saved successfully.");
                        }
                    }
                    System.out.println("Exiting the program. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 9);
    }
}
